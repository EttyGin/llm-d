{{/*
common validations
*/}}
{{- define "llm-d-router.validations.gateway.common" -}}
{{- if not (include "llmd.modelServers.matchLabels" $ | fromYaml) }}
{{- fail "router.modelServers.matchLabels is required — set it, or set global.llmd.guide so the umbrella can derive it" }}
{{- end }}
{{- end -}}
