{{/*
Create a default fully qualified app name for inferenceGateway.
*/}}
{{- define "llm-d-router-gateway.fullname" -}}
  {{- $gw := .Values.httpRoute.inferenceGatewayName | default (include "llmd.identity.gateway" .) -}}
  {{- if $gw -}}
    {{- $gw | trunc 63 | trimSuffix "-" -}}
  {{- else -}}
    {{- printf "%s-inference-gateway" .Release.Name| trunc 63 | trimSuffix "-" -}}
  {{- end -}}
{{- end -}}
